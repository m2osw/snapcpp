// Module:  Log4cplus
// File:    qt4debugappender.cxx
// Created: 6/2012
// Author:  Vaclav Zeman
//
//
//  Copyright (C) 2012-2015, Vaclav Zeman. All rights reserved.
//  
//  Redistribution and use in source and binary forms, with or without modifica-
//  tion, are permitted provided that the following conditions are met:
//  
//  1. Redistributions of  source code must  retain the above copyright  notice,
//     this list of conditions and the following disclaimer.
//  
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//  
//  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
//  FITNESS  FOR A PARTICULAR  PURPOSE ARE  DISCLAIMED.  IN NO  EVENT SHALL  THE
//  APACHE SOFTWARE  FOUNDATION  OR ITS CONTRIBUTORS  BE LIABLE FOR  ANY DIRECT,
//  INDIRECT, INCIDENTAL, SPECIAL,  EXEMPLARY, OR CONSEQUENTIAL  DAMAGES (INCLU-
//  DING, BUT NOT LIMITED TO, PROCUREMENT  OF SUBSTITUTE GOODS OR SERVICES; LOSS
//  OF USE, DATA, OR  PROFITS; OR BUSINESS  INTERRUPTION)  HOWEVER CAUSED AND ON
//  ANY  THEORY OF LIABILITY,  WHETHER  IN CONTRACT,  STRICT LIABILITY,  OR TORT
//  (INCLUDING  NEGLIGENCE OR  OTHERWISE) ARISING IN  ANY WAY OUT OF THE  USE OF
//  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include <log4cplus/config.hxx>
#include <log4cplus/qt4debugappender.h>
#include <log4cplus/helpers/loglog.h>
#include <log4cplus/helpers/property.h>
#include <log4cplus/spi/factory.h>
#include <log4cplus/spi/loggingevent.h>
#include <sstream>
#include <iomanip>
#include <QtGlobal>
#include <log4cplus/config/windowsh-inc.h>


// Forward Declarations
namespace log4cplus
{


Qt4DebugAppender::Qt4DebugAppender ()
    : Appender ()
{ }


Qt4DebugAppender::Qt4DebugAppender (helpers::Properties const & props)
    : Appender (props)
{ }


Qt4DebugAppender::~Qt4DebugAppender ()
{
    destructorImpl ();
}


void
Qt4DebugAppender::close ()
{ }


void
Qt4DebugAppender::append (spi::InternalLoggingEvent const & ev)
{
    // TODO: Expose log4cplus' internal TLS to use here.
    tostringstream oss;    
    layout->formatAndAppend(oss, ev);

    LogLevel const ll = ev.getLogLevel ();
    void (* log_func) (const char *, ...) = 0;

    if (ll >= ERROR_LOG_LEVEL)
        log_func = qCritical;
    else if (ll >= WARN_LOG_LEVEL)
        log_func = qWarning;
    else
        log_func = qDebug;
    
    log_func ("%s", LOG4CPLUS_TSTRING_TO_STRING (oss.str ()).c_str ());
}


void
Qt4DebugAppender::registerAppender ()
{
    log4cplus::spi::AppenderFactoryRegistry & reg
        = log4cplus::spi::getAppenderFactoryRegistry ();
    LOG4CPLUS_REG_APPENDER (reg, Qt4DebugAppender);
}


} // namespace log4cplus


#if defined (_WIN32)
extern "C"
BOOL WINAPI DllMain(LOG4CPLUS_DLLMAIN_HINSTANCE,  // handle to DLL module
                    DWORD fdwReason,     // reason for calling function
                    LPVOID)  // reserved
{
    // Perform actions based on the reason for calling.
    switch( fdwReason ) 
    { 
    case DLL_PROCESS_ATTACH:
    {
        log4cplus::Qt4DebugAppender::registerAppender ();
        break;
    }

    case DLL_THREAD_ATTACH:
        break;

    case DLL_THREAD_DETACH:
        break;

    case DLL_PROCESS_DETACH:
        break;
    }

    return TRUE;  // Successful DLL_PROCESS_ATTACH.
}

#endif // defined (_WIN32)
