#!/bin/sh

autoreconf -i $@
