

#include "commontest.h"

const std::string zipios::TestFiles::TEST_ZIPFILE_NAME;
