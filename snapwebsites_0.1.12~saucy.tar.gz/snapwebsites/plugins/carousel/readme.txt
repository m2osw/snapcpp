

A round carousel with scaling capabilities:
(https://github.com/addyosmani/jquery-roundrr)

	jquery-roundrr.js
	jquery-animate-css-rotate-scale.js

Test on: http://alexis.m2osw.com/roundrr/

