In order to add admin rights to a user, run the following command:

snapbackend -d -a makeroot -p ROOT_USER_EMAIL=user@domain.tld

